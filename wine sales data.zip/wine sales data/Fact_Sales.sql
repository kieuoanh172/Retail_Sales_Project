USE [testhmd]
GO

/****** Object:  Table [dbo].[FactSales]    Script Date: 4/11/2025 7:12:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FactSales](
	[SalesID] [int] IDENTITY(1,1) NOT NULL,
	[DateKey] [date] NULL,
	[StoreKey] [int] NULL,
	[CategoryKey] [int] NULL,
	[VendorKey] [int] NULL,
	[BottlesSold] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[SalesID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[FactSales]  WITH CHECK ADD FOREIGN KEY([CategoryKey])
REFERENCES [dbo].[DimCategory] ([CategoryKey])
GO

ALTER TABLE [dbo].[FactSales]  WITH CHECK ADD FOREIGN KEY([DateKey])
REFERENCES [dbo].[DimDate] ([Datekey])
GO

ALTER TABLE [dbo].[FactSales]  WITH CHECK ADD FOREIGN KEY([StoreKey])
REFERENCES [dbo].[DimStore] ([StoreKey])
GO

ALTER TABLE [dbo].[FactSales]  WITH CHECK ADD FOREIGN KEY([VendorKey])
REFERENCES [dbo].[DimVendor] ([VendorKey])
GO

